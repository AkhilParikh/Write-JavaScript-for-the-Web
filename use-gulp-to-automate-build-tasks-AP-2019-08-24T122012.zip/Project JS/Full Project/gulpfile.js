const gulp = require('gulp');
const jshint = require('gulp-jshint');
const babel = require('gulp-babel');
const runSequence = require('run-sequence');
const browserSync = require('browser-sync').create();
const uglify = require('gulp-uglify');

gulp.task('default', (callback) => {
  runSequence(['processHTML', 'processJS', 'copyImages','babelPolyfill'], 'watch', callback);
});

gulp.task('processHTML', () => {
  gulp.src('*.html')
    .pipe(gulp.dest('dist'));
});

gulp.task('processJS', () => {
  gulp.src('*.js')
    .pipe(jshint({
      esversion: 6
    }))
    .pipe(jshint.reporter('default'))
    .pipe(babel(
      {
        presets: ['@babel/preset-env']
      }
    ))
    .pipe(uglify().on('error', function(e){
      console.log(e);
    }))
    .pipe(gulp.dest('dist'));
});

gulp.task('copyImages', () => {
  gulp.src('images/octopus.svg')
      .pipe(gulp.dest('dist/images'));
});

gulp.task('babelPolyfill', () => {
    gulp.src('node_modules/babel-polyfill/browser.js')
        .pipe(gulp.dest('dist/node_modules/babel-polyfill'));
});

gulp.task('browserSync', () => {
  browserSync.init({
    server: './dist',
    port: 8080,
    ui: {
      port: 8081
    }
  });
});

gulp.task('watch', ['browserSync'], () => {
    gulp.watch('*.js', ['processJS']);
    gulp.watch('*.html', ['processHTML']);
 
    gulp.watch('*.js', browserSync.reload);
    gulp.watch('*.html', browserSync.reload);
});


